//UTILIZARE AJAX
//Metodele: GET, POST, PUT, DELETE

const list = document.getElementById('list');
const formName = document.getElementById('formName');
const formUrl = document.getElementById('formUrl');
const addButton = document.getElementById('addButton');
let updateButton = document.getElementById('updateButton');

function getGallery() {
    fetch('http://localhost:3000/creations')
        .then(function (response) {
            response.json().then(function (creations) {
                appendGalleryToDOM(creations);
            });
        });
};

function postGallery() {
    const postObject = {
        name: formName.value,
        img: formUrl.value
    }
    fetch('http://localhost:3000/creations', {
        method: 'post',
        headers: {
            "Content-type": "application/json"
        },
        body: JSON.stringify(postObject)
    }).then(function () {
        getGallery();
        resetForm();
    });
}

function deleteGallery(id) {
    fetch(`http://localhost:3000/creations/${id}`, {
        method: 'DELETE',
    }).then(function () {
        getGallery();
    });
}

function updateGallery(id) {
    const putObject = {
        name: formName.value,
        img: formUrl.value
    }
    fetch(`http://localhost:3000/creations/${id}`, {
        method: 'PUT',
        headers: {
            "Content-type": "application/json"
        },
        body: JSON.stringify(putObject)
    }).then(function () {
        getGallery();

        addButton.disabled = false;
        clearUpdateButtonEvents();
        resetForm();
    });
}

function editGallery(pic) {
    formName.value = pic.name;
    formUrl.value = pic.img;
    
    addButton.disabled = true;
    clearUpdateButtonEvents();
    updateButton.disabled = false;
    updateButton.addEventListener('click', function () {
        updateGallery(pic.id)
    });

}

function appendGalleryToDOM(creations) {
    while (list.firstChild) {
        list.removeChild(list.firstChild);
    }
    for (let i = 0; i < creations.length; i++) {
        let img = document.createElement('img');
        img.src = creations[i].img;
        let name = document.createElement('span');
        name.innerText = creations[i].name;

        let editButton = document.createElement('button')
        editButton.addEventListener('click', function () {
            editGallery(creations[i])
        });
        editButton.innerText = 'Edit';
        let deleteButton = document.createElement('button')
        deleteButton.addEventListener('click', function () {
            deleteGallery(creations[i].id)
        });
        deleteButton.innerText = 'Delete';
        let container = document.createElement('div');
        container.appendChild(img);
        container.appendChild(name);
        container.appendChild(editButton);
        container.appendChild(deleteButton);

        list.appendChild(container);
    }
}

function resetForm() {
    formName.value = '';
    formUrl.value = '';
}
function clearUpdateButtonEvents() {
    let newUpdateButton = updateButton.cloneNode(true);
    updateButton.parentNode.replaceChild(newUpdateButton, updateButton);
    updateButton = document.getElementById('updateButton');
}
addButton.addEventListener('click', postGallery);

getGallery();