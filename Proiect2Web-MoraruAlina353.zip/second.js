//Evenimente Javascript declansate de butoane

function thanksMessage(){
    var nume = document.getElementById("name").value;
    var tara = document.getElementById("country").value;

    var mesaj = document.getElementById("message");
    mesaj.innerHTML = 'Thank you, ' + nume + ' from ' + tara + ', for visiting my website!';
}

var button = document.getElementById('grateful-button');
button.addEventListener('click', thanksMessage);

function bigImg(imagine) {
    imagine.style.height = "216px";
    imagine.style.width = "384px";
}

function normalImg(imagine) {
    imagine.style.height = "54px";
    imagine.style.width = "96px";
}

function jokeFunction() {
    alert("No entry yet. :)");
}
