Proiectul Javascript

- pentru fiecare pagina .html am creat un fisier corespunzator .js in care am distribuit cerintele pentru al doilea proiect
- cerinta/ele rezolvate in fiecare fisier .js sunt notate in comentarii, la inceputul codului