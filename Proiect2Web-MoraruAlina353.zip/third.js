//Eveniment javascript declansat de tastatura

function jokeFunction() {
    alert("No entry yet. :)");
}