//Crearea elementelor HTML
var img = document.createElement('img');
img.src = 'images/capture.jpg';
document.body.appendChild(img);

//Editarea elementelor HTML
var items = document.getElementsByTagName('h2');
    items[0].innerHTML = "My Blog";
    items[1].innerHTML = "My Creations";
    items[2].innerHTML = "My Info";

//Stergerea elementelor HTML
var item = document.getElementById("me");
item.remove();


