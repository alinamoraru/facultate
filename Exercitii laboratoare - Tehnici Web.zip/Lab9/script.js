
var Filme = [
    {
        titlu: "Titanic",
        durata:120,
        actori : ['Kate Winslet', 'Leonardo DiCaprio'],
        vizualizare: true,
        pic: 'https://upload.wikimedia.org/wikipedia/commons/thumb/d/db/Titanic-Cobh-Harbour-1912.JPG/330px-Titanic-Cobh-Harbour-1912.JPG'
    },
    {
        titlu: "Frozen",
        durata: 100,
        actori : ['Actor1', 'Actor2'],
        vizualizare: true,
        pic: 'https://lumiere-a.akamaihd.net/v1/images/eu_frozen_gt_rush_r_f17ace62.jpeg'
    }    
];


var lista = document.createElement('ul');
for (var i = 0; i < Filme.length; i++){
    var filmItem = document.createElement('li');
    var filmImag = document.createElement('img');

    filmImag.src = Filme[i].pic;
    filmItem.appendChild(filmImag);

    var text = document.createTextNode(Filme[i].titlu 
    + ', ' + Filme[i].durata + ', ' + Filme[i].actori.join()
    + ', ' + Filme[i].vizualizare);

    filmItem.appendChild(text);

    if (Filme[i].vizualizare) {
        filmItem.style.color = 'purple';
    }
    lista.appendChild(filmItem);
}
document.body.appendChild(lista);
