document.body.style.fontFamily = 'Arial, sans-serif';
document.getElementById('nickname').innerHTML = 'Alina Moraru';
document.getElementById('favorites').innerHTML = 'Music';
document.getElementById('hometown').innerHTML = 'Bucuresti';


var items = document.getElementsByTagName('li');
for (var i = 0; i < items.length; i++){
    items[i].className = "list-item";
}

var img = document.createElement('img');
img.src = 'eu.jpg';
document.body.firstChild.firstChild.firstChild.appendChild(img);