const list = document.getElementById('list');
const formName = document.getElementById('formName');
const formUrl = document.getElementById('formUrl');
const addButton = document.getElementById('addButton');
let updateButton = document.getElementById('updateButton');

function getDogs() {
    fetch('http://localhost:3000/dogs')
        .then(function (response) {
            response.json().then(function (dogs) {
                appendDogsToDOM(dogs);
            });
        });
};

function postDog() {
    const postObject = {
        name: formName.value,
        img: formUrl.value
    }
    fetch('http://localhost:3000/dogs', {
        method: 'post',
        headers: {
            "Content-type": "application/json"
        },
        body: JSON.stringify(postObject)
    }).then(function () {
        getDogs();
        resetForm();
    });
}

function deleteDog(id) {
    fetch(`http://localhost:3000/dogs/${id}`, {
        method: 'DELETE',
    }).then(function () {
        getDogs();
    });
}

function updateDog(id) {
    const putObject = {
        name: formName.value,
        img: formUrl.value
    }
    fetch(`http://localhost:3000/dogs/${id}`, {
        method: 'PUT',
        headers: {
            "Content-type": "application/json"
        },
        body: JSON.stringify(putObject)
    }).then(function () {
        getDogs();

        addButton.disabled = false;
        clearUpdateButtonEvents();
        resetForm();
    });
}

function editDog(dog) {
    formName.value = dog.name;
    formUrl.value = dog.img;
    

    addButton.disabled = true;
    clearUpdateButtonEvents();
    updateButton.disabled = false;
    updateButton.addEventListener('click', function () {
        updateDog(dog.id)
    });

}

function appendDogsToDOM(dogs) {
    while (list.firstChild) {
        list.removeChild(list.firstChild);
    }
    for (let i = 0; i < dogs.length; i++) {
        let img = document.createElement('img');
        img.src = dogs[i].img;
        let name = document.createElement('span');
        name.innerText = dogs[i].name;

        let editButton = document.createElement('button')
        editButton.addEventListener('click', function () {
            editDog(dogs[i])
        });
        editButton.innerText = 'Edit';
        let deleteButton = document.createElement('button')
        deleteButton.addEventListener('click', function () {
            deleteDog(dogs[i].id)
        });
        deleteButton.innerText = 'Delete';
        let container = document.createElement('div');
        container.appendChild(img);
        container.appendChild(name);
        container.appendChild(editButton);
        container.appendChild(deleteButton);

        list.appendChild(container);
    }
}

function resetForm() {
    formName.value = '';
    formUrl.value = '';
}

function clearUpdateButtonEvents() {
    let newUpdateButton = updateButton.cloneNode(true);
    updateButton.parentNode.replaceChild(newUpdateButton, updateButton);
    updateButton = document.getElementById('updateButton');
}
addButton.addEventListener('click', postDog);

getDogs();