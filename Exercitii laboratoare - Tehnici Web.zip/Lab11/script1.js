var movePixels = 10; // number of pixels
var delayMs = 50; // number of miliseconds
var dogTimer = null;
var sessionTime;
      
     // Move the image on screen with 10px
     function dogWalk() {
        var img = document.getElementsByTagName('img')[0];
        var currentLeft = parseInt(img.style.left);
        img.style.left = (currentLeft + movePixels) + 'px';
            // reset image position to start
        if (currentLeft > (window.innerWidth-img.width)) {
            img.style.left = '0px';
            }
        }
      
    //call dogWalk function every 50 ms
    function startDogWalk() {
        dogTimer = window.setInterval(dogWalk, delayMs);
        }

    function onStartClick(){
        startDogWalk();

        //session timer
        stopSessionTimer();
        startSessionTimer();

        //disable start button
        document.getElementById('start-button').disabled = true;   
    }

    //add startWalk event handler
    var startButton = document.getElementById('start-button');
    startButton.addEventListener('click', onStartClick);

    //remove dogWalk to be called every 50ms
    function onStopClick() {
        window.clearInterval(dogTimer);

        //session timer
        stopSessionTimer();
        startSessionTimer();

        //disable start button
        document.getElementById('start-button').disabled = false;   
    }

    //add stopWalk event handler
    var stopButton = document.getElementById('stop-button');
    stopButton.addEventListener('click', onStopClick);

    //change speed
    function onSpeedClick(){
        movePixels += 5;
        var speed = movePixels * (1000/50);
        //append speed info to #info
        document.getElementById('info').innerHTML = 'Current speed: ' + speed + ' px/second';

        //session timer
        stopSessionTimer();
        startSessionTimer();
    }

    //add speed event handler
    var speedButton = document.getElementById('speed-button');
    speedButton.addEventListener('click', onSpeedClick);

    //create the reset speedbutton
    var resetSpeedButton = document.createElement("button");
    resetSpeedButton.innerHTML = "Reset Speed";

    //append somewhere
    var buttons = document.getElementById("buttons");
    buttons.appendChild(resetSpeedButton);

    //reset speed
    function onResetSpeedClick(){
        movePixels = 10;
        var slowSpeed = movePixels * (1000/50);
        //append speed info to #info
        document.getElementById('info').innerHTML = 'Current speed: ' + slowSpeed + ' px/second';
        
        //session timer
        stopSessionTimer();
        startSessionTimer();
    }

    //add reset speed event handler
    resetSpeedButton.addEventListener("click",onResetSpeedClick);

    //start session timer
    function startSessionTimer() {
        sessionTime = window.setTimeout(function(){
            alert("Sesiune expirata");
        },45000);
    }

    //stop session timer
    function stopSessionTimer() {
        window.clearTimeout(sessionTime);
    }

    //call session time
    startSessionTimer();