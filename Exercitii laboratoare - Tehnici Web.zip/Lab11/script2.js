app = {
    movePixels : 10, // number of pixels
    delayMs : 50, // number of miliseconds
    dogTimer : null,
    sessionTime: null,
      
     // Move the image on screen with 10px
    dogWalk: function() {
        var img = document.getElementsByTagName('img')[0];
        var currentLeft = parseInt(img.style.left);
        img.style.left = (currentLeft + this.movePixels) + 'px';
            // reset image position to start
        if (currentLeft > (window.innerWidth-img.width)) {
            img.style.left = '0px';
            }
        },
      
    //call dogWalk function every 50 ms
    startDogWalk: function() {
        this.dogTimer = window.setInterval(this.dogWalk.bind(this), this.delayMs);
        },

    onStartClick: function(){
        this.startDogWalk();

        //session timer
        this.stopSessionTimer();
        this.startSessionTimer();

        //disable start button
        document.getElementById('start-button').disabled = true;   
    },

    //remove dogWalk to be called every 50ms
    onStopClick: function() {
        window.clearInterval(this.dogTimer);

        //session timer
        this.stopSessionTimer();
        this.startSessionTimer();

        //disable start button
        document.getElementById('start-button').disabled = false;   
    },

    //change speed
    onSpeedClick: function() {
        this.movePixels += 5;
        var speed = this.movePixels * (1000/50);
        //append speed info to #info
        document.getElementById('info').innerHTML = 'Current speed: ' + speed + ' px/second';

        //session timer
        this.stopSessionTimer();
        this.startSessionTimer();
    },

    //reset speed
    onResetSpeedClick: function(){
        this.movePixels = 10;
        var slowSpeed = this.movePixels * (1000/50);
        //append speed info to #info
        document.getElementById('info').innerHTML = 'Current speed: ' + slowSpeed + ' px/second';
        
        //session timer
        this.stopSessionTimer();
        this.startSessionTimer();
    },

    //start session timer
    startSessionTimer: function() {
        sessionTime = window.setTimeout(function(){
            alert("Sesiune expirata");
        }, 45000);
    },

    //stop session timer
    stopSessionTimer: function() {
        window.clearTimeout(this.sessionTime);
    },

init: function() {
    //add startWalk event handler
    var startButton = document.getElementById('start-button');
    startButton.addEventListener('click', this.onStartClick.bind(this));

    //add stopWalk event handler
    var stopButton = document.getElementById('stop-button');
    stopButton.addEventListener('click', this.onStopClick.bind(this));

    //add speed event handler
    var speedButton = document.getElementById('speed-button');
    speedButton.addEventListener('click', this.onSpeedClick.bind(this));

    //create the reset speedbutton
    var resetSpeedButton = document.createElement("button");
    resetSpeedButton.innerHTML = "Reset Speed";

    //append somewhere
    var buttons = document.getElementById("buttons");
    buttons.appendChild(resetSpeedButton);

    //add reset speed event handler
    resetSpeedButton.addEventListener("click",this.onResetSpeedClick.bind(this));
 
    //call session time
    this.startSessionTimer();
    },

}

app.init(); 