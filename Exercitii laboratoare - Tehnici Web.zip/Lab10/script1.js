var square = document.getElementById("square-button");
var half = document.getElementById("half-button");
var percent = document.getElementById("percent-button");
var area = document.getElementById("area-button");

function patrat(){
    var nr = document.getElementById("square-input").value;
    document.getElementById("solution").innerHTML = nr*nr;
}

function jumatate(){
    var nr = document.getElementById("half-input").value;
    document.getElementById("solution").innerHTML = nr/2;
}

function procent(){
    var proc = document.getElementById("percent1-input").value;
    var nr = document.getElementById("percent2-input").value;
    document.getElementById("solution").innerHTML = (nr*proc)/100;
}

function aria(){
    var r = document.getElementById("area-input").value;
    document.getElementById("solution").innerHTML = 3.14*r*r;
}

square.addEventListener('click',patrat);
half.addEventListener('click',jumatate);
percent.addEventListener('click',procent);
area.addEventListener('click',aria);


