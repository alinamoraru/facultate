function makeStory(){
    var loc = document.getElementById("places").value;
    var adj = document.getElementById("adjective").value;
    var om = document.getElementById("person").value;
    var poveste = document.getElementById("story");
    poveste.innerHTML = om + ' a vizitat ' + adj + ' ' + loc;
}

var button = document.getElementById('story-button');
button.addEventListener('click', makeStory);

