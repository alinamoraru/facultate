var Person = {
    nume : "Lisa A. Romano",
    varsta : 52,
    calitati : ["empatica", "curajoasa", "determinata"],
};


