var element = [1,2,3];

function multiplicator(element)
{
    return 2*element;
}