var Film = {
    titlu: "Moara cu noroc",
    durata: 130,
    actori: ["Constantin Codrescu", "Olga Tudorache", "Geo Barton"],
    print: function(){
        
           return "<<" + this.titlu + ">>" + " a durat " + this.durata + " minute. Actori: " + this.actori;   
        }
};
