var blackFridayCart = {
    telefon: "350",
    consola: "250",
    televizor: "450",
    iepurasPlus: "10.60",
    cercei: "20.34",
    geanta: "22.36",
    getCartValue: function(blackFridayCart){
        return Number(this.telefon) + Number(this.consola) + Number(this.televizor) + Number(this.iepurasPlus) + Number(this.cercei) + Number(this.geanta);
    }
  };