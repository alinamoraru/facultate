--Model - rezolvari
--1
set serveroutput on;
/
create or replace procedure decc(cod_dep number) is
type t_angajati is table of employees%rowtype;
v_angajati t_angajati;
begin
select * bulk collect into v_angajati
from employees e
where to_char(hire_date, 'YYYY')>1988
and (select count(*) from job_history h
     where h.employee_id = e.employee_id)>=2
and department_id = cod_dep;
if sql%notfound then
   raise_application_error(-20000, 'nu s-a gasit niciun angajat');
end if;
for i in 1..v_angajati.count loop
  dbms_output.put_line(v_angajati(i).first_name||' '||
                       v_angajati(i).last_name);
end loop;
end decc;

/
execute decc(80); --sau 80 pt departament care exista
/
drop procedure decc;
/

--2
--it works ma frienddd!!!
--s-a delcarat un tip tablou imbricat de varchar2
-- si apoi o variabila job_list de acest tip
create or replace type ges is table of varchar2(20);
/
alter table employees add job_list ges
nested table job_list store as ge;
/
declare
var employees.employee_id%type:=&5;
cursor curs(param employees.employee_id%type)
is select job_id from job_history where employee_id=param;
altavar ges := ges(); --constructor

begin
for i in curs(var) loop
  altavar.extend;
  altavar(altavar.count):=i.job_id;
end loop;
/*
open curs(var);
fetch curs bulk collect into altavar;
close curs;
*/
update employees set job_list = altavar where employee_id=var;
end;
--works as well, pe verificatelea!!!
--3
create or replace trigger prob3
after update of manager_id
on departments
for each row
begin
update employees
set salary = salary - 0.2*salary
where employee_id=:old.manager_id;
update employees
set salary = salary +0.2*salary
where employee_id=:new.manager_id;
update employees
set manager_id=:new.manager_id
where manager_id=:old.manager_id;
end;
/
update departments
set manager_id=101
where department_id=90;
/