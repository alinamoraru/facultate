--EX 3
--bloc
declare
  v_cantitate NUMBER(3) :=300;
  v_mesaj VARCHAR2(255) := 'Produs 1';
begin
  --subbloc TOATE DIN SUBBLOC NU SUNT VIZIBILE IN AFARA LUI
  declare
    v_cantitate number(3) :=1;
    v_mesaj varchar2(255) :='Produs 2';
    v_locatie varchar2(50) :='Europa';
  begin
    v_cantitate := v_cantitate +1;
    v_locatie := v_locatie ||'de est';
  end;
  v_cantitate:= v_cantitate +1;
  v_mesaj := v_mesaj||' se afla in stoc';
  v_locatie := v_locatie||' de est';
end;

--EX 5
set serveroutput on;
declare
  v_oras locations.city%TYPE;
begin
  select city
  into v_oras
  from departments d, locations l
  where d.location_id = l.location_id and department_id=30;
  dbms_output.put_line('Orasul este '||v_oras);
end;
set serverouput off;

--EX 7
--cum sa ceri ceva utilizatorului cu prompt
accept p_cod_dep PROMPT 'Introduceti codul departamentului:'
declare
  --asa se initial cu ce se ia de la tastatura (next row)
  v_cod_dep departments.department_id%TYPE := &p_cod_dep; 
  v_numar NUMBER(3) := 0;
  v_comentariu VARCHAR2(10);
begin
  select count(*)
  into v_numar
  from employees
  where department_id = v_cod_dep;
  if v_numar < 10 then v_comentariu := 'mic';
  elsif v_numar between 10 and 30 then v_comentariu :='mediu';
  else v_comentariu := 'mare';
  end if;
  dbms_output.put_line('Departamentul avand codul '
  ||v_cod_dep||' este de tip '||v_comentariu);
end;

--EX 8
--nu merge
set serveroutput on
set verify off
define p_cod_dep=50
define p_com=10
declare
  v_cod_dep emp_pnu.departament_id%TYPE := &p_cod_dep;
  v_com NUMBER(2);
begin
  update emp_pnu
  set comission_pct = &p_com/100
  where department_id = v_cod_dep;
  if sql%rowcount = 0 then --sql%rowcount intoarce cate linii au fost afectate
    dbms_output.put_line('Nicio linie actualizata');
  else
    dbms_output.put_line (sql%rowcount || 'linii actualizate');
  end if;  
end;
set verify on
set serveroutput off


end