--1
set serveroutput on;
/
create or replace procedure p1 (codloc locations.location_id%type) is
--declarari locale, folosim un cursor pentru colectare mai multe linii ca rezultat
cursor crr is
select first_name, last_name, salary
from employees e inner join departments d
on e.department_id=d.department_id
where d.location_id = codloc and
salary > (select avg(salary) from employees);
emi crr%rowtype; --am declarat in sectiunea de declarari 
--a procedurii o variabila de tipul cursorului definit
begin
if crr%isopen then
close crr;
end if;
open crr;
if sql%notfound then
dbms_output.put_line('nu exista');
else
loop
  fetch crr into emi; --am pus rezultatul cursorului in variabila pregatita
  exit when crr%notfound;
  dbms_output.put_line(emi.first_name|| ' '||emi.salary);
end loop;
end if;
end;
/
execute p1(150);
/
--2
--2.a
create or replace trigger anunt
before update --insert/delete se real trigger-e separate
on employees
begin
dbms_output.put_line('Se modifica');
end anunt;
/
--2.b
create or replace trigger nrmax
before insert or update of department_id
on employees
for each row
declare
  function getnrang(codDep employees.department_id%type)
  return number is rezultat number:=0;
begin
  select count(*) into rezultat 
  from employees
  where department_id = codDep;
  return rezultat;
  end getnrang;

--acum begin-ul de la trigger
begin
  if :new.department_id IS NOT NULL then
  if getnrang(:new.department_id) >=20 then
  IF INSERTING THEN
        raise_application_error(-20001, 'Nu se poate insera un angajat deoarece un departament ar avea mai mult de 20 de angajati');
  ELSIF UPDATING THEN
        raise_application_error(-20001, 'Nu se poate actualiza departamentul unui angajat deoarece un departament ar avea mai mult de 20 de angajati');
  end if;
  end if;
  end if;
end;
/
--3
--3.a
declare
codang employees.employee_id%type := &cod;
cursor ceva(empid employees.employee_id%type) is
  select employee_id,department_id,job_id
  from job_history
  where employee_id=empid;
  --declar iar o var de tip cursorului care e un tip de rezultat
  varceva ceva%rowtype;
begin
if ceva%isopen then
close ceva;
end if;
open ceva(codang);
loop
  fetch ceva into varceva;
  exit when ceva%notfound;
  dbms_output.put_line('Angajatul cu ID-ul ' || varceva.employee_id || ' a lucrat in departamentul ' || varceva.department_id || ' avand jobul ' || varceva.job_id);
END LOOP;
close ceva;
end;