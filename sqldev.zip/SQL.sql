--Fisier Oracle - interogari variate

--1
SELECT *
FROM a_expozitii
WHERE data > '3-Dec-2016';
--2: ce tipuri de echipamente putem gasi la statui
SELECT COUNT(id_statuie),tip
FROM a_echipamente
GROUP BY tip;
--3: care au fost primele agentii de presa cu care s-au 
--   incheiat contracte in Romania (in ordine)
SELECT nume,MAX(id_presa)
FROM a_agentii_presa
WHERE tara='Romania'
GROUP BY nume;
--4
SELECT nume,prenume,muzeu
FROM a_delegati
WHERE tara!='UK'
ORDER BY nume;
--5
SELECT invitat,titlu
FROM a_prezentari
WHERE data BETWEEN '3-Dec-2016' AND '7-Dec-2016';
--6
SELECT nume, prenume
FROM a_membri_staff
WHERE tara='Italia' OR tara='Danemarca';
--7
SELECT *
FROM a_expozitii
WHERE data NOT BETWEEN '03-Dec-2016' AND '07-DEC-2016';
--8: rownum = navigare intre inregistrari
SELECT * 
FROM a_lista_membri_staff  
WHERE rownum <= 3;
--9
SELECT id_locatie, adresa, descriere
FROM a_locatii
WHERE adresa LIKE 'A%';
--10
SELECT *
FROM a_expozitii NATURAL JOIN a_prezentari;
--11
SELECT id_voluntar,nume, titlu, data
FROM a_voluntari
NATURAL JOIN a_prezentari
WHERE nume NOT LIKE 'S%';
--12
SELECT *
FROM a_expozitii JOIN a_agenti_paza 
USING (data);
--13
SELECT p.titlu,p.invitat, p.data, p.descriere
FROM a_prezentari p
INNER JOIN a_expozitii 
ON p.id_expozitie = a_expozitii.id_expozitie
WHERE a_expozitii.nume = 'Testamentul dacilor';
--14
SELECT d.nume, d.prenume, d.tara,h.nume, h.adresa
FROM a_hoteluri h
FULL OUTER JOIN a_delegati d
ON h.id_delegat = d.id_delegat
WHERE d.tara = 'Italia';
--15
SELECT p.nume,p.tara,p.mod_difuzare, c.tip as Tipul_contractului
FROM a_contracte_promovare c
FULL OUTER JOIN a_posturi_tv p
ON c.id_contract = p.id_contract
WHERE p.tara <> 'Romania';