--lab2 15
/
--am creat un tip de care avem nevoie pentru tabel
--tipul e tot un obiect
create or replace type obj_info is object
(cod_angajat number, job_angajat varchar2(10));
/
--creez tabloul de obiecte ca TIP INTAI
create or replace type t_imb is table of obj_info;
/
--adaugam (si cream)tabelul imbricat in tabelul DEPT
alter table dept_amm add info t_imb
nested table info store as t_info;
/
declare
t_info t_imb := t_imb();
obj obj_info := obj_info(null,null);
begin
obj.cod_angajat := 5;
obj.job_angajat := 'Ceva';
t_info.extend;
t_info(1) := obj;
update dept_amm set info = t_info
where department_id = 90;
end;
/
select info from dept_amm where department_id = 90;
/
select i.* from dept_amm d, table(d.info) i;
/
select i.* from dept_amm d, table(d.info) i;
/
--lab3 5 OK
create table top_salarii_pnu
(salary number);

accept p_num prompt 'Numarul de angajati: '

declare

v_num number := &p_num; --& cand dam de la tastatura date
v_sal employees.salary%type;
cursor empamm_cursor is
  select distinct salary
  from employees
  order by salary desc;
  
begin
if empamm_cursor%isopen then
close empamm_cursor;
end if;
open empamm_cursor;
fetch empamm_cursor into v_sal;
while empamm_cursor%rowcount <= v_num and 
      empamm_cursor%found loop
        insert into top_salarii_pnu
        values(v_sal);
        fetch empamm_cursor into v_sal;
end loop;
 close empamm_cursor;
end;

/
select * from top_salarii_pnu;
/
delete top_salarii_pnu;
/
--lab4
set serveroutput on;
/
create or replace package pamm is
  type t_ang is table of employees%rowtype;
  v_ang t_ang;
end;
create or replace function infoAngajati(cod_manager number)
  return pamm.t_ang is
  begin
  select * bulk collect into pamm.v_ang
    from employees where hire_date > (select max(hire_date) from employees
                                      where (manager_id = cod_manager));
    return pamm.v_ang;
  end infoAngajati;
    
declare
  v_val pamm.t_ang;
begin
  v_val := infoAngajati(100);
  dbms_output.put_line(v_val.count);
  for i in 1..v_val.count loop
    dbms_output.put_line(v_val(i).first_name);
  end loop;
end;
/
select manager_id from employees;
/
--probl triggeri
create or replace package pam is
salariu_minim number;
salariu_mediu number;
salariu_maxim number;
end;

create or replace trigger t_update_amm
before update of salary on emp_amm
begin
  select min(salary),max(salary), avg(salary) INTO
  pam.salariu_minim, pam.salariu_mediu, pam.salariu_maxim
  from emp_amm;
end;
/
create or replace trigger t_update_foreach_amm
before update of salary on emp_amm
for each row begin
  if (:old.salary = pam.salariu_maxim) and
     (:new.salary < pam.salariu_mediu) then
  raise_application_error(-20100, 'vezi cond.1');
  elsif (:old.salary = pam.salariu_minim) and
     (:new.salary > pam.salariu_mediu) then
  raise_application_error(-20100, 'vezi cond.2');
  end if;
end;
/
update emp_amm
set salary = 10000
where salary = (select min(salary) from emp_amm);
/
update emp_amm
set salary = 1000
where salary = (select max(salary) from emp_amm);

