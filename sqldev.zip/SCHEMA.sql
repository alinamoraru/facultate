--Fisier Oracle - creare + populare tabele
CREATE TABLE a_expozitii
(id_expozitie NUMBER(4) PRIMARY KEY,
 nume VARCHAR2(100),
 data DATE
);
INSERT INTO a_expozitii VALUES (1, 'Poporul statornic', '1-Dec-2016');
INSERT INTO a_expozitii VALUES (2, 'Stramosii nostri', '3-Dec-2016');
INSERT INTO a_expozitii VALUES (3, 'Istorie si valoare', '5-Dec-2016');
INSERT INTO a_expozitii VALUES (4, 'Testamentul dacilor', '7-Dec-2016');
INSERT INTO a_expozitii VALUES (5, 'Credinta neamului', '9-Dec-2016');
--
CREATE TABLE a_prezentari
(id_prezentare NUMBER(4) PRIMARY KEY,
 titlu VARCHAR2(30),
 data DATE,
 invitat VARCHAR2(30),  
 descriere VARCHAR2(100),
 id_expozitie NUMBER(4) NOT NULL,
 CONSTRAINT fk_expozitie
 FOREIGN KEY (id_expozitie) REFERENCES a_expozitii
);
INSERT INTO a_prezentari VALUES (1, 'Poporul de altadata', '1-Dec-2016', 'Dan Puric', 'O perspectiva deosebita a stramosilor nostri', 1);
INSERT INTO a_prezentari VALUES (2, 'Cunoasterea neamului', '3-Dec-2016', 'Mircea Badea', 'Imparatasirea cunostintelor', 2);
INSERT INTO a_prezentari VALUES (3, 'Un scurt istoric', '5-Dec-2016', 'Florentina Nitu', 'Omul potrivit pentru subiectul potrivit', 3);
INSERT INTO a_prezentari VALUES (4, 'O viziune feminina', '7-Dec-2016', 'Andreea Marin', 'Farmec, istorie si surprize', 4);
INSERT INTO a_prezentari VALUES (5, 'Festivitatea de inchidere', '9-Dec-2016', 'Neagu Djuvara', 'Un centenar inzestrat despre pasiunea sa', 5);
--
CREATE TABLE a_statui
(id_statuie NUMBER(4) PRIMARY KEY,
 nume VARCHAR2(30),
 locul_descoperirii VARCHAR2(100),
 material VARCHAR2(100),
 dimensiuni VARCHAR2(20),
 datare VARCHAR2(20),
 provenienta VARCHAR2(100),
 id_expozitie NUMBER(4) NOT NULL,
 CONSTRAINT fk_statui
 FOREIGN KEY (id_expozitie) REFERENCES a_expozitii
);
INSERT INTO a_statui VALUES (1, 'Capilatus', 'Forul lui Traian', 'Marmura alba, cu vine albastre', 'h = 195-200 cm','Domnia lui Traian', 'Musei Capitolini, Roma, Italia', 1);
INSERT INTO a_statui VALUES (2, 'Statuie de Dac', 'Gradina Palatului Cesi', 'Marmura gri', 'h = 3,24 m', 'Domnia lui Hadrian', 'Museo Canonica, Roma, Italia', 2);
INSERT INTO a_statui VALUES (3, 'Barbar asezat','Necunoscut', 'Breccia verde', 'h = 1,63 m', 'Sec. II d.Hr.', 'Muzeul Luvru, Paris, Franta',2);
INSERT INTO a_statui VALUES (4, 'Barbar','Ramleh Egipt', 'Marmura alba', 'h = 103 cm', 'Sec. II d.Hr.', 'British Museum, Londra, UK', 3);
INSERT INTO a_statui VALUES (5, 'Cap de dac','Necunoscut', 'Marmura gri', 'h = 0,44 m', 'Sec. XVII', 'Museo del Prado, Madrid, Spania', 4);
INSERT INTO a_statui VALUES (6, 'Bust de dac', 'Necunoscut', 'Marmura', 'h = 0,52 m', '117 d. Hr.', 'Ny Carlsberg Glyptotek, Copenhaga, Danemarca', 5);
--
CREATE TABLE a_locatii
(id_locatie NUMBER(4) PRIMARY KEY,
 adresa VARCHAR2(100),
 descriere VARCHAR2(30),
 id_expozitie NUMBER(4) NOT NULL,
 CONSTRAINT fk_locatii
 FOREIGN KEY (id_expozitie) REFERENCES a_expozitii
);
INSERT INTO a_locatii VALUES (1, 'Piata Universitatii', 'In inima Bucurestiului',1);
INSERT INTO a_locatii VALUES (2, 'Muzeul Satului, Parcul Herastrau', 'Cel mai potrivit loc',2);
INSERT INTO a_locatii VALUES (3, 'Facultatea de istorie - amfiteatru', 'Un loc incarcat de istorie',3);
INSERT INTO a_locatii VALUES (4, 'Biblioteca Nationala, Blvd. Unirii', '-',4);
INSERT INTO a_locatii VALUES (5, 'Academia Romana, Calea Victoriei', 'Spatiu al cercetarii',5);
--
CREATE TABLE a_voluntari
(id_voluntar NUMBER(4) PRIMARY KEY,
 nume VARCHAR2(30),
 prenume VARCHAR2(30),  
 rol VARCHAR2(20),
 id_prezentare NUMBER(4) NOT NULL,
  CONSTRAINT fk_voluntari
 FOREIGN KEY (id_prezentare) REFERENCES a_prezentari
);
INSERT INTO a_voluntari VALUES (1, 'Ionescu','David', 'primire', 1);
INSERT INTO a_voluntari VALUES (2, 'Stefan', 'Andreea', 'stand', 2);
INSERT INTO a_voluntari VALUES (3, 'Mihai', 'Monica', 'primire', 3);
INSERT INTO a_voluntari VALUES (4, 'Stan', 'Alin', 'stand', 5);
INSERT INTO a_voluntari VALUES (5, 'Marinescu', 'Lucia', 'bufet', 5);
--
CREATE TABLE a_agenti_paza
(id_agent NUMBER(4) PRIMARY KEY,
 nume VARCHAR2(30),
 prenume VARCHAR2(30),
 data DATE,
 firma VARCHAR2(30),
 id_expozitie NUMBER(4) NOT NULL,
   CONSTRAINT fk_agenti_paza
 FOREIGN KEY (id_expozitie) REFERENCES a_expozitii
);
INSERT INTO a_agenti_paza VALUES (1, 'Marin', 'Ion', '1-Dec-2016', 'Securytas Group', 1);
INSERT INTO a_agenti_paza VALUES (2, 'Dinca', 'Andrei', '3-Dec-2016','Securytas Group', 2);
INSERT INTO a_agenti_paza VALUES (3, 'Savu', 'Bogdan', '5-Dec-2016','Securytas Group', 3);
INSERT INTO a_agenti_paza VALUES (4, 'Stanciu', 'Mario', '7-Dec-2016', 'Securytas Group', 4);
INSERT INTO a_agenti_paza VALUES (5, 'Popescu', 'Denis', '9-Dec-2016', 'Securytas Group', 5);
INSERT INTO a_agenti_paza VALUES (6, 'Raducan', 'Darius', '9-Dec-2016', 'Securytas Group', 5);
--
CREATE TABLE a_contracte_promovare
(id_contract NUMBER(4) PRIMARY KEY,
 tip VARCHAR2(15),
 id_expozitie NUMBER(4) NOT NULL,
 CONSTRAINT fk_contracte_promovare
 FOREIGN KEY (id_expozitie) REFERENCES a_expozitii
);
INSERT INTO a_contracte_promovare VALUES(1, 'televiziune', 1);
INSERT INTO a_contracte_promovare VALUES(2, 'televiziune', 2);
INSERT INTO a_contracte_promovare VALUES(3, 'televiziune', 3);
INSERT INTO a_contracte_promovare VALUES(4, 'presa', 4);
INSERT INTO a_contracte_promovare VALUES(5, 'televiziune', 5);
INSERT INTO a_contracte_promovare VALUES(6, 'presa', 5);
--
CREATE TABLE a_posturi_tv
(id_tv NUMBER(4) PRIMARY KEY,
 nume VARCHAR2(30),
 tara VARCHAR2(30),
 mod_difuzare VARCHAR2(15),
 id_contract NUMBER(4) NOT NULL,
  CONSTRAINT fk_posturi_tv
 FOREIGN KEY (id_contract) REFERENCES a_contracte_promovare
);
INSERT INTO a_posturi_tv VALUES (1, 'TVR1', 'Romania', 'direct',1);
INSERT INTO a_posturi_tv VALUES (2, 'Romania TV', 'Romania', 'direct',2);
INSERT INTO a_posturi_tv VALUES (3, 'TVR Cultural', 'Romania', 'inregistrat',3);
INSERT INTO a_posturi_tv VALUES (4, 'Piu Blu', 'Italia', 'inregistrat',4);
INSERT INTO a_posturi_tv VALUES (5, 'France News', 'Franta', 'inregistrat',5);
--
CREATE TABLE a_agentii_presa
(id_presa NUMBER(4) PRIMARY KEY,
 nume VARCHAR2(30),
 tara VARCHAR2(30),
 mod_promovare VARCHAR2(15),
 id_contract NUMBER(4) NOT NULL,
 CONSTRAINT fk_agentii_presa
 FOREIGN KEY (id_contract) REFERENCES a_contracte_promovare
);
INSERT INTO a_agentii_presa VALUES (1, 'Jurnalul National', 'Romania', 'articol',4);
INSERT INTO a_agentii_presa VALUES (2, 'Agerpres', 'Romania', 'reportaj',4);
INSERT INTO a_agentii_presa VALUES (3, 'Gandul', 'Romania', 'articol',6);
INSERT INTO a_agentii_presa VALUES (4, 'EFE', 'Spania', 'interviu',6);
INSERT INTO a_agentii_presa VALUES (5, 'Gidana', 'Danemarca', 'reportaj',6);
--
CREATE TABLE a_delegati
(id_delegat NUMBER(4) PRIMARY KEY,
 nume VARCHAR2(30),
 prenume VARCHAR2(30),
 muzeu VARCHAR2(30),
 tara VARCHAR2(30),
 id_statuie NUMBER(4) NOT NULL,
  CONSTRAINT fk_delegati
 FOREIGN KEY (id_statuie) REFERENCES a_statui
);
INSERT INTO a_delegati VALUES (1, 'Brando', 'Agata', 'Musei Capitolini', 'Italia', 1);
INSERT INTO a_delegati VALUES (2, 'Belluci', 'Franco', 'Museo Canonica', 'Italia', 2);
INSERT INTO a_delegati VALUES (3, 'Mauger', 'Berthe', 'Muzeul Luvru', 'Franta', 3);
INSERT INTO a_delegati VALUES (4, 'Adams', 'John', 'British Museum', 'UK', 4);
INSERT INTO a_delegati VALUES (5, 'Iglesias', 'Eduardo', 'Museo del Prado', 'Spania', 5);
INSERT INTO a_delegati VALUES (6, 'Ingmann', 'Grethe', 'Ny Carlsberg Glyptotek', 'Danemarca', 6);
INSERT INTO a_delegati VALUES (7, 'Ingmann', 'J�rgen', 'Ny Carlsberg Glyptotek', 'Danemarca', 6);
--
CREATE TABLE a_membri_staff
(id_membru NUMBER(4) PRIMARY KEY,
 nume VARCHAR2(30),
 prenume VARCHAR2(30),
 specializare VARCHAR2(20),
 tara VARCHAR2(30),
 id_statuie NUMBER(4) NOT NULL,
   CONSTRAINT fk_membri_staff
 FOREIGN KEY (id_statuie) REFERENCES a_statui
);
INSERT INTO a_membri_staff VALUES (1, 'Vampa', 'Luigi', 'montare', 'Italia', 1);
INSERT INTO a_membri_staff VALUES (2, 'Garlen', 'Francisca', 'intretinere', 'Italia', 2);
INSERT INTO a_membri_staff VALUES (3, 'Dion', 'Emmelie', 'montare', 'Franta', 3);
INSERT INTO a_membri_staff VALUES (4, 'Robin', 'Blade', 'deplasare', 'UK', 4);
INSERT INTO a_membri_staff VALUES (5, 'Suarez', 'Federico', 'intretinere', 'Spania', 5);
INSERT INTO a_membri_staff VALUES (6, 'Maelger', 'Julian', 'montare', 'Danemarca', 6);
INSERT INTO a_membri_staff VALUES (7, 'Schwinger', 'Arnlod', 'deplasare', 'Danemarca', 6);
--
CREATE TABLE a_echipamente
(id_echipament NUMBER(4) PRIMARY KEY,
 tip VARCHAR2(20),
 cerinta VARCHAR2(30),
 id_statuie NUMBER(4) NOT NULL,
  CONSTRAINT fk_echipamente
 FOREIGN KEY (id_statuie) REFERENCES a_statui
);
INSERT INTO a_echipamente VALUES (1, 'montare', '-',1);
INSERT INTO a_echipamente VALUES (2, 'montare', '-',3);
INSERT INTO a_echipamente VALUES (3, 'intretinere', 'necesita grija',4);
INSERT INTO a_echipamente VALUES (4, 'deplasare', '-',5);
INSERT INTO a_echipamente VALUES (5, 'deplasare', 'mecanism de prindere',6);
--
CREATE TABLE a_hoteluri
(id_hotel NUMBER(4) PRIMARY KEY,
 nume VARCHAR2(30),
 adresa VARCHAR2(100), 
 capacitate NUMBER(2),
 id_delegat NUMBER(4) NOT NULL,
 id_membru NUMBER(4) NOT NULL,
   CONSTRAINT fk_hoteluri1
 FOREIGN KEY (id_delegat) REFERENCES a_delegati,
   CONSTRAINT fk_hoteluri2
 FOREIGN KEY (id_membru) REFERENCES a_membri_staff
);
INSERT INTO a_hoteluri VALUES (1, 'Intercontinental', 'Centru', '20', 1, 1);
INSERT INTO a_hoteluri VALUES (2, 'Epoque', 'Metrou Constantin Brancoveanu', '10', 2, 2);
INSERT INTO a_hoteluri VALUES (3, 'Relax Comfort Suites', 'Piata Unirii', '35', 3, 3);
INSERT INTO a_hoteluri VALUES (4, 'Minerva', 'Gheorghe Manu', '40', 4, 4);
INSERT INTO a_hoteluri VALUES (5, 'Palladium', 'Metrou 1 Decembrie', '30', 5, 5);
INSERT INTO a_hoteluri VALUES (6, 'Cismigiu', 'Parcul Cismigiu', '15', 6, 6);
INSERT INTO a_hoteluri VALUES (7, 'Caro', 'Metrou Grozavesti', '75', 7, 7);
--
CREATE TABLE a_lista_statui
(id_lista_statui NUMBER(4) PRIMARY KEY,
 id_expozitie NUMBER(4) NOT NULL,
 id_statuie NUMBER(4) NOT NULL,
  CONSTRAINT fk_lista1_statui
 FOREIGN KEY (id_expozitie) REFERENCES a_expozitii,
   CONSTRAINT fk_lista2_statui
 FOREIGN KEY (id_statuie) REFERENCES a_statui
);
INSERT INTO a_lista_statui VALUES(1,1,1);
INSERT INTO a_lista_statui VALUES(2,1,2);
INSERT INTO a_lista_statui VALUES(3,1,3);
INSERT INTO a_lista_statui VALUES(4,2,1);
INSERT INTO a_lista_statui VALUES(5,2,3);
INSERT INTO a_lista_statui VALUES(6,2,3);
INSERT INTO a_lista_statui VALUES(7,3,2);
INSERT INTO a_lista_statui VALUES(8,3,4);
INSERT INTO a_lista_statui VALUES(9,3,6);
INSERT INTO a_lista_statui VALUES(10,4,1);
INSERT INTO a_lista_statui VALUES(11,4,2);
INSERT INTO a_lista_statui VALUES(12,5,1);
INSERT INTO a_lista_statui VALUES(13,5,2);
INSERT INTO a_lista_statui VALUES(14,5,3);
INSERT INTO a_lista_statui VALUES(15,5,4);
INSERT INTO a_lista_statui VALUES(16,5,5);
INSERT INTO a_lista_statui VALUES(17,5,6);
--
CREATE TABLE a_lista_membri_staff
(id_lista_membri_staff NUMBER(4) PRIMARY KEY,
 id_membru NUMBER(4) NOT NULL,
 id_hotel NUMBER(4) NOT NULL,
   CONSTRAINT fk_lista1_membri
 FOREIGN KEY (id_membru) REFERENCES a_membri_staff,
   CONSTRAINT fk_lista2_membri
 FOREIGN KEY (id_hotel) REFERENCES a_hoteluri
);
INSERT INTO a_lista_membri_staff VALUES(1,1,1);
INSERT INTO a_lista_membri_staff VALUES(2,2,2);
INSERT INTO a_lista_membri_staff VALUES(3,3,3);
INSERT INTO a_lista_membri_staff VALUES(4,4,4);
INSERT INTO a_lista_membri_staff VALUES(5,5,5);
--